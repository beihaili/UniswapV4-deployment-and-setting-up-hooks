import { BigNumber, Contract } from "ethers";
// @ts-ignore
import { ethers } from "hardhat";
//export this file to use in other files
export const token0Address = "0xFD471836031dc5108809D173A067e8486B9047A3"
export const token1Address =  "0xc351628EB244ec633d5f21fBD6621e1a683B1181"
export const hookAddress =  "0xB0D4afd8879eD9F52b28595d31B441D079B2Ca07"
export const myliquidityProviderAddress =  "0x1429859428C0aBc9C2C47C8Ee9FBaf82cFA0F20f"
export const poolmanagerAddress =  "0xcbEAF3BDe82155F56486Fb5a1072cb8baAf547cc"

export const provider = new ethers.providers.JsonRpcProvider("http://localhost:8545");
export const wallet = new ethers.Wallet("0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80", provider)

const poolmanagerAbi = require('./abi/LimitOrder.json').abi;
const erc20Abi = require('./abi/Token0.json').abi;
const myliquidityproviderAbi = require('./abi/MyLiquidityProvider.json').abi;
const hookAbi = require('./abi/LimitOrder.json').abi;

export let token0 = new ethers.Contract(token0Address, erc20Abi, wallet);
export let token1 = new ethers.Contract(token1Address, erc20Abi, wallet);
export let poolManager = new ethers.Contract(poolmanagerAddress,poolmanagerAbi,wallet);
export let MyLiquidityProvider = new ethers.Contract(myliquidityProviderAddress,myliquidityproviderAbi,wallet);
export let hook = new ethers.Contract(hookAddress,hookAbi,wallet);

const DYNAMIC_FEE_FLAG = 0x800000;
export let poolKey = {
    currency0: token0Address,
    currency1: token1Address,
    fee: 60,
    tickSpacing: 60,
    hooks:     hookAddress,
};